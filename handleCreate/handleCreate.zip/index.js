const dynamoose = require('dynamoose')

// create schema

const personSchema = new dynamoose.Schema({
    id:String,
    age:Number,
    name:String,
 
})
// create a model
const personModel =dynamoose.model('people-demo',personSchema)

console.log ('lalala----',event.body)

let {id,age,name} = event.queryStringParameters

console.log ('-------', person)
let person ={id, age, name}


exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from handleCrea!'),
    };
    return response;
};
